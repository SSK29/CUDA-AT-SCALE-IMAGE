#!/bin/bash
set -e

mkdir -p data/output results

echo "Building CUDA project..."
make

echo ""
echo "Running GPU image processing..."
./cuda_image_processor data/input data/output | tee results/execution_log.txt

echo ""
echo "Execution complete."
echo "Log saved to results/execution_log.txt"
echo "Processed images are in data/output/"
