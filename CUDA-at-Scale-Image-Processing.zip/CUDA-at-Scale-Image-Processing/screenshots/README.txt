Place screenshots of successful CUDA build and execution here.
Recommended screenshots:
1. nvcc build completing successfully
2. GPU name and 100 images processed
3. results/execution_log.txt
4. an input image and a processed output image
