/*
 * CUDA at Scale: GPU-Accelerated Batch Image Processing
 *
 * Processes a large collection of small PPM images using CUDA kernels.
 * Operations:
 *   1. RGB -> grayscale
 *   2. 3x3 Gaussian-style blur
 *
 * No CPU-only implementation is used for the computational work.
 */

#include <cuda_runtime.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <filesystem>
#include <chrono>
#include <iomanip>
#include <algorithm>
#include <sstream>
#include <stdexcept>

namespace fs = std::filesystem;

#define CUDA_CHECK(call) do { \
    cudaError_t err = (call); \
    if (err != cudaSuccess) { \
        std::cerr << "CUDA error: " << cudaGetErrorString(err) \
                  << " at " << __FILE__ << ":" << __LINE__ << std::endl; \
        return 1; \
    } \
} while(0)

struct Image {
    int width = 0, height = 0;
    std::vector<unsigned char> rgb;
};

static bool readPPM(const fs::path& path, Image& img) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;

    std::string magic;
    in >> magic;
    if (magic != "P6") return false;

    auto skipComments = [&]() {
        while (in >> std::ws && in.peek() == '#') {
            std::string line;
            std::getline(in, line);
        }
    };

    skipComments();
    in >> img.width;
    skipComments();
    in >> img.height;
    skipComments();

    int maxval;
    in >> maxval;
    in.get(); // consume one whitespace byte

    if (img.width <= 0 || img.height <= 0 || maxval != 255) return false;

    img.rgb.resize(static_cast<size_t>(img.width) * img.height * 3);
    in.read(reinterpret_cast<char*>(img.rgb.data()), img.rgb.size());
    return in.good();
}

static bool writePGM(const fs::path& path, const std::vector<unsigned char>& data,
                     int width, int height) {
    std::ofstream out(path, std::ios::binary);
    if (!out) return false;
    out << "P5\n" << width << " " << height << "\n255\n";
    out.write(reinterpret_cast<const char*>(data.data()), data.size());
    return out.good();
}

__global__ void rgbToGrayKernel(const unsigned char* rgb,
                                unsigned char* gray,
                                int width, int height) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x < width && y < height) {
        int p = y * width + x;
        int i = p * 3;
        float value = 0.299f * rgb[i] +
                      0.587f * rgb[i + 1] +
                      0.114f * rgb[i + 2];
        gray[p] = static_cast<unsigned char>(value);
    }
}

__global__ void blur3x3Kernel(const unsigned char* input,
                              unsigned char* output,
                              int width, int height) {
    int x = blockIdx.x * blockDim.x + threadIdx.x;
    int y = blockIdx.y * blockDim.y + threadIdx.y;

    if (x < width && y < height) {
        // 3x3 Gaussian-style kernel:
        // 1 2 1
        // 2 4 2
        // 1 2 1
        const int k[3][3] = {
            {1, 2, 1},
            {2, 4, 2},
            {1, 2, 1}
        };

        int sum = 0;
        int weight = 0;

        for (int ky = -1; ky <= 1; ++ky) {
            for (int kx = -1; kx <= 1; ++kx) {
                int xx = min(max(x + kx, 0), width - 1);
                int yy = min(max(y + ky, 0), height - 1);
                int w = k[ky + 1][kx + 1];
                sum += input[yy * width + xx] * w;
                weight += w;
            }
        }

        output[y * width + x] =
            static_cast<unsigned char>(sum / weight);
    }
}

static std::vector<fs::path> findInputs(const fs::path& dir) {
    std::vector<fs::path> files;
    if (!fs::exists(dir)) return files;

    for (const auto& entry : fs::directory_iterator(dir)) {
        if (!entry.is_regular_file()) continue;
        auto ext = entry.path().extension().string();
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
        if (ext == ".ppm") files.push_back(entry.path());
    }
    std::sort(files.begin(), files.end());
    return files;
}

int main(int argc, char** argv) {
    fs::path inputDir = argc > 1 ? argv[1] : "data/input";
    fs::path outputDir = argc > 2 ? argv[2] : "data/output";

    fs::create_directories(outputDir);

    int deviceCount = 0;
    CUDA_CHECK(cudaGetDeviceCount(&deviceCount));

    if (deviceCount == 0) {
        std::cerr << "No CUDA-capable GPU detected.\n";
        return 1;
    }

    cudaDeviceProp prop{};
    CUDA_CHECK(cudaGetDeviceProperties(&prop, 0));

    std::cout << "============================================\n";
    std::cout << " CUDA AT SCALE - GPU IMAGE PROCESSING\n";
    std::cout << "============================================\n";
    std::cout << "GPU: " << prop.name << "\n";
    std::cout << "Compute Capability: " << prop.major << "." << prop.minor << "\n";
    std::cout << "Global Memory: "
              << std::fixed << std::setprecision(2)
              << prop.totalGlobalMem / (1024.0 * 1024.0 * 1024.0)
              << " GB\n\n";

    auto files = findInputs(inputDir);
    std::cout << "Input directory: " << inputDir << "\n";
    std::cout << "Images found: " << files.size() << "\n";

    if (files.empty()) {
        std::cerr << "No .ppm images found.\n";
        return 1;
    }

    cudaEvent_t start, stop;
    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));

    const dim3 threads(16, 16);
    size_t successful = 0;
    size_t failed = 0;
    float totalGpuMs = 0.0f;
    double totalWallMs = 0.0;

    for (size_t n = 0; n < files.size(); ++n) {
        Image img;
        if (!readPPM(files[n], img)) {
            std::cerr << "Failed to read: " << files[n] << "\n";
            ++failed;
            continue;
        }

        size_t rgbBytes = img.rgb.size();
        size_t pixels = static_cast<size_t>(img.width) * img.height;
        size_t grayBytes = pixels;

        unsigned char *d_rgb = nullptr, *d_gray = nullptr, *d_blur = nullptr;

        auto wallStart = std::chrono::high_resolution_clock::now();

        CUDA_CHECK(cudaMalloc(&d_rgb, rgbBytes));
        CUDA_CHECK(cudaMalloc(&d_gray, grayBytes));
        CUDA_CHECK(cudaMalloc(&d_blur, grayBytes));

        CUDA_CHECK(cudaMemcpy(d_rgb, img.rgb.data(), rgbBytes,
                              cudaMemcpyHostToDevice));

        dim3 blocks((img.width + threads.x - 1) / threads.x,
                    (img.height + threads.y - 1) / threads.y);

        CUDA_CHECK(cudaEventRecord(start));

        rgbToGrayKernel<<<blocks, threads>>>(d_rgb, d_gray,
                                               img.width, img.height);
        CUDA_CHECK(cudaGetLastError());

        blur3x3Kernel<<<blocks, threads>>>(d_gray, d_blur,
                                            img.width, img.height);
        CUDA_CHECK(cudaGetLastError());

        CUDA_CHECK(cudaEventRecord(stop));
        CUDA_CHECK(cudaEventSynchronize(stop));

        float gpuMs = 0.0f;
        CUDA_CHECK(cudaEventElapsedTime(&gpuMs, start, stop));

        std::vector<unsigned char> output(grayBytes);
        CUDA_CHECK(cudaMemcpy(output.data(), d_blur, grayBytes,
                              cudaMemcpyDeviceToHost));

        auto wallEnd = std::chrono::high_resolution_clock::now();
        double wallMs = std::chrono::duration<double, std::milli>(
            wallEnd - wallStart).count();

        fs::path outputPath =
            outputDir / (files[n].stem().string() + "_processed.pgm");

        if (!writePGM(outputPath, output, img.width, img.height)) {
            std::cerr << "Failed to write: " << outputPath << "\n";
            ++failed;
        } else {
            ++successful;
            totalGpuMs += gpuMs;
            totalWallMs += wallMs;
        }

        cudaFree(d_rgb);
        cudaFree(d_gray);
        cudaFree(d_blur);

        if ((n + 1) % 10 == 0 || n + 1 == files.size()) {
            std::cout << "Processed " << (n + 1) << "/" << files.size()
                      << " images\n";
        }
    }

    CUDA_CHECK(cudaEventDestroy(start));
    CUDA_CHECK(cudaEventDestroy(stop));

    std::cout << "\n============================================\n";
    std::cout << " RESULTS\n";
    std::cout << "============================================\n";
    std::cout << "Total images:       " << files.size() << "\n";
    std::cout << "Successful:         " << successful << "\n";
    std::cout << "Failed:             " << failed << "\n";
    std::cout << "Total GPU kernel:   " << totalGpuMs << " ms\n";
    std::cout << "Average GPU/image:  "
              << (successful ? totalGpuMs / successful : 0.0f) << " ms\n";
    std::cout << "Total wall time:    " << totalWallMs << " ms\n";
    std::cout << "Average wall/image: "
              << (successful ? totalWallMs / successful : 0.0) << " ms\n";
    std::cout << "\nGPU computation completed successfully.\n";

    return failed == 0 ? 0 : 2;
}
