# CUDA at Scale - GPU-Accelerated Batch Image Processing

## Project Overview

This project demonstrates GPU-accelerated image processing on a large collection
of images using NVIDIA CUDA.

The program processes **100 small images** and performs two computationally
intensive operations on the GPU:

1. RGB-to-grayscale conversion
2. 3x3 Gaussian-style blur

The implementation uses custom CUDA kernels, so it satisfies the assignment
requirement that GPU computation must be present.

## Why this meets the assignment

- 100+ input images
- CUDA GPU kernels
- Batch image processing
- GPU execution timing
- Output images
- Execution log
- Reproducible build/run commands
- No CPU-only or CPU-multithreaded solution

## Directory Structure

```text
CUDA-at-Scale-Image-Processing/
├── src/
│   └── main.cu
├── data/
│   ├── input/       # 100 sample PPM images
│   └── output/      # generated processed PGM images
├── results/
│   └── execution_log.txt
├── screenshots/
├── Makefile
├── run.sh
└── README.md
```

## Requirements

- NVIDIA GPU
- CUDA Toolkit with `nvcc`
- Linux environment
- `make`

The code was intentionally written without requiring OpenCV or other external
image libraries. PPM/PGM are used so the project can run in a CUDA lab with
minimal dependencies.

## Build

```bash
make
```

Equivalent command:

```bash
nvcc -O2 -std=c++17 src/main.cu -o cuda_image_processor
```

## Run

```bash
./run.sh
```

Or:

```bash
./cuda_image_processor data/input data/output
```

## Expected output

```text
============================================
 CUDA AT SCALE - GPU IMAGE PROCESSING
============================================
GPU: NVIDIA ...
Compute Capability: ...
Global Memory: ... GB

Input directory: data/input
Images found: 100
Processed 10/100 images
Processed 20/100 images
...
Processed 100/100 images

============================================
 RESULTS
============================================
Total images:       100
Successful:         100
Failed:             0
Total GPU kernel:   ... ms
Average GPU/image:  ... ms
Total wall time:    ... ms
Average wall/image: ... ms

GPU computation completed successfully.
```

## CUDA Implementation

The first kernel maps one GPU thread to each pixel for RGB-to-grayscale
conversion.

The second kernel applies a 3x3 Gaussian-style filter. A 16x16 CUDA thread
block configuration is used.

```cpp
dim3 threads(16, 16);
dim3 blocks(
    (width + threads.x - 1) / threads.x,
    (height + threads.y - 1) / threads.y
);
```

## Proof of Execution

Run:

```bash
./run.sh | tee results/execution_log.txt
```

Then commit:

- `results/execution_log.txt`
- sample output images from `data/output/`
- screenshots showing the successful CUDA execution

## Suggested peer-review description

This project implements a CUDA-based batch image processing pipeline. A
collection of 100 images is loaded and processed using GPU kernels. The
application performs RGB-to-grayscale conversion followed by a 3x3
Gaussian-style blur. CUDA events are used to measure GPU kernel execution
time. The results demonstrate how GPU parallelism can process many image
pixels
efficiently and provide measurable GPU execution statistics.

## Repository

Create a public GitHub repository and upload this project.

Example repository name:

`cuda-at-scale-image-processing`
